# Become The Tree Spirit (Fabric, Minecraft 1.21.4)

This is the source project for the mod, prepared with the project files at the repository root. It is not a compiled `.jar` yet.

## Get the mod JAR without installing Gradle locally

1. Create or sign in to a GitHub account.
2. Create a **public** repository (for example, `become-the-tree-spirit`).
3. Upload the *contents of this folder* to the repository root (the `build.gradle` file and `.github` folder should be at the top level).
4. Open the repository's **Actions** tab and select the **build** workflow. Click **Run workflow** if it has not run automatically.
5. When the run succeeds, open the run and download the artifact named `become-the-tree-spirit-jar`.
6. Inside the downloaded artifact, use `become-the-tree-spirit-0.1.0.jar` (not a `-sources.jar`, if present).
7. Install Fabric Loader for **Minecraft Java 1.21.4**, install the matching Fabric API, and put the mod JAR in your Minecraft `mods` folder.

## Local build

Requires JDK 21 and Gradle 8.12. From this folder, run `gradle build`; the JAR should appear in `build/libs/`.

**Important:** The source README describes this release as untested and not previously compiled. A successful build only confirms compilation; test the mod in a backup world before using it.
