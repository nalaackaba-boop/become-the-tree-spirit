package com.treespirit;

import java.util.function.Function;
import net.minecraft.item.Item;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Identifier;

public class ModItems {
    /** Diamond-tier, but mining speed 8 + efficiency V (5*5+1 = 26) baked in. */
    public static final ToolMaterial SPIRIT = new ToolMaterial(
        BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1561, 34.0f, 3.0f, 10, ItemTags.DIAMOND_TOOL_MATERIALS);

    public static final Item SPIRIT_AXE = reg("spirit_axe", s -> new SpiritAxeItem(SPIRIT, 5.0f, -3.0f, s));

    private static Item reg(String name, Function<Item.Settings, Item> factory) {
        RegistryKey<Item> k = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(TreeSpiritMod.ID, name));
        return Registry.register(Registries.ITEM, k, factory.apply(new Item.Settings().registryKey(k)));
    }

    public static void init() {}
}
