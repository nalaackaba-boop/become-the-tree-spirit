package com.treespirit;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.GlobalPos;

public class SpiritLogic {
    private static final Map<UUID, Integer> OFF_LOG = new HashMap<>();
    private static final Map<UUID, Long> SWAP_UNTIL = new HashMap<>();

    public static void openSwapWindow(ServerPlayerEntity p) {
        SWAP_UNTIL.put(p.getUuid(), p.getServerWorld().getTime() + 200);
    }

    private static boolean isValidHeart(BlockState s) {
        return s.isOf(ModBlocks.HEART_LOG) || s.isOf(Blocks.GLOWSTONE)
            || s.isOf(Blocks.SEA_LANTERN) || s.isOf(Blocks.GOLD_BLOCK);
    }

    public static void tick(MinecraftServer server, ServerPlayerEntity p) {
        GlobalPos h = p.getAttached(TreeSpiritMod.HEART);
        if (h == null || p.isCreative() || p.isSpectator() || !p.isAlive()) return;
        ServerWorld w = p.getServerWorld();
        long time = w.getTime();

        // --- standing on a log? ---
        BlockPos feet = BlockPos.ofFloored(p.getX(), p.getY() - 0.2, p.getZ());
        BlockState below = w.getBlockState(feet);
        boolean spirit = below.isOf(ModBlocks.SPIRIT_LOG) || below.isOf(ModBlocks.HEART_LOG);
        boolean onLog = spirit || below.isIn(BlockTags.LOGS);

        if (spirit && time % 20 == 0) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 60, 0, true, false, true));
        }
        if (onLog) {
            OFF_LOG.put(p.getUuid(), 0);
        } else {
            int t = OFF_LOG.merge(p.getUuid(), 1, Integer::sum);
            if (t > 40 && t % 40 == 0) p.damage(w, w.getDamageSources().magic(), 1.0f);
        }

        // --- is the heart intact? ---
        ServerWorld hw = server.getWorld(h.dimension());
        if (hw == null) return;
        BlockPos hp = h.pos();
        if (!hw.getChunkManager().isChunkLoaded(hp.getX() >> 4, hp.getZ() >> 4)) return;

        long until = SWAP_UNTIL.getOrDefault(p.getUuid(), 0L);
        if (time > until && !isValidHeart(hw.getBlockState(hp))) {
            p.removeAttached(TreeSpiritMod.HEART);
            p.sendMessage(Text.literal("Your heart log was destroyed."), false);
            p.kill(w);
            return;
        }

        // --- creepers are drawn to an exposed heart ---
        if (time % 40 == 0) {
            for (CreeperEntity c : hw.getEntitiesByClass(CreeperEntity.class, new Box(hp).expand(24), e -> true)) {
                c.getNavigation().startMovingTo(hp.getX() + 0.5, hp.getY() + 1, hp.getZ() + 0.5, 1.1);
            }
        }
    }
}
