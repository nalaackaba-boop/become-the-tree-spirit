package com.treespirit;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.GlobalPos;

public class TreeSpiritMod implements ModInitializer {
    public static final String ID = "treespirit";

    /** Where each player's heart log is. Saved with the player. */
    public static final AttachmentType<GlobalPos> HEART =
        AttachmentRegistry.createPersistent(Identifier.of(ID, "heart"), GlobalPos.CODEC);

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModItems.init();

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) SpiritLogic.tick(server, p);
        });

        // Spirits may not place planks / wood blocks.
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (player.getAttached(HEART) != null && player.getStackInHand(hand).getItem() instanceof BlockItem bi) {
                Block b = bi.getBlock();
                if (b.getDefaultState().isIn(BlockTags.PLANKS)) {
                    if (!world.isClient) player.sendMessage(Text.literal("A tree spirit cannot place wood planks."), true);
                    return ActionResult.FAIL;
                }
            }
            return ActionResult.PASS;
        });

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.NATURAL).register(e -> {
            e.add(ModBlocks.SPIRIT_LOG);
            e.add(ModBlocks.HEART_LOG);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(ModItems.SPIRIT_AXE));

        // /treespirit begin  -> plants your heart log under your feet and starts the challenge
        // /treespirit end    -> releases you from the challenge
        CommandRegistrationCallback.EVENT.register((dispatcher, reg, env) ->
            dispatcher.register(CommandManager.literal("treespirit")
                .then(CommandManager.literal("begin").executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    BlockPos pos = p.getBlockPos().down();
                    p.getServerWorld().setBlockState(pos, ModBlocks.HEART_LOG.getDefaultState());
                    p.setAttached(HEART, GlobalPos.create(p.getServerWorld().getRegistryKey(), pos));
                    p.sendMessage(Text.literal("You are now a tree spirit. Protect your heart log."), false);
                    return 1;
                }))
                .then(CommandManager.literal("end").executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    p.removeAttached(HEART);
                    p.sendMessage(Text.literal("You have left the spirit tree."), false);
                    return 1;
                }))));
    }
}
