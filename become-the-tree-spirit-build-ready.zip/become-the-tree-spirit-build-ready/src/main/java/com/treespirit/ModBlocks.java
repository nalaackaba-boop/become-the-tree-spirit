package com.treespirit;

import java.util.function.Function;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.PillarBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public class ModBlocks {
    public static final Block SPIRIT_LOG = reg("spirit_log", PillarBlock::new,
        AbstractBlock.Settings.copy(Blocks.OAK_LOG).luminance(s -> 3));
    public static final Block HEART_LOG = reg("heart_log", Block::new,
        AbstractBlock.Settings.copy(Blocks.OAK_LOG).luminance(s -> 12).strength(4.0f));

    private static <T extends Block> T reg(String name, Function<AbstractBlock.Settings, T> factory, AbstractBlock.Settings settings) {
        Identifier id = Identifier.of(TreeSpiritMod.ID, name);
        RegistryKey<Block> bk = RegistryKey.of(RegistryKeys.BLOCK, id);
        T block = factory.apply(settings.registryKey(bk));
        Registry.register(Registries.BLOCK, bk, block);
        RegistryKey<Item> ik = RegistryKey.of(RegistryKeys.ITEM, id);
        Registry.register(Registries.ITEM, ik, new BlockItem(block, new Item.Settings().registryKey(ik).useBlockPrefixedTranslationKey()));
        return block;
    }

    public static void init() {}
}
