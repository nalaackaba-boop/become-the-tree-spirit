package com.treespirit;

import net.minecraft.block.BlockState;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.ToolMaterial;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.GlobalPos;

public class SpiritAxeItem extends AxeItem {
    public SpiritAxeItem(ToolMaterial m, float dmg, float speed, Settings s) { super(m, dmg, speed, s); }

    /** Right-click your own heart block to open a 10 second window to swap it. */
    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        if (ctx.getPlayer() instanceof ServerPlayerEntity p) {
            GlobalPos h = p.getAttached(TreeSpiritMod.HEART);
            BlockPos pos = ctx.getBlockPos();
            if (h != null && h.pos().equals(pos) && h.dimension().equals(p.getServerWorld().getRegistryKey())) {
                SpiritLogic.openSwapWindow(p);
                p.sendMessage(Text.literal("10 seconds to replace your heart block (glowstone, sea lantern, or gold)."), true);
                return ActionResult.SUCCESS;
            }
        }
        return super.useOnBlock(ctx);
    }
}
